import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm";


// =====================================================
// SUPABASE
// =====================================================

const supabase = createClient(
    "https://gocoupvzzsgouwdkdmzu.supabase.co",
    "PASTE_YOUR_SUPABASE_ANON_KEY_HERE"
);


// =====================================================
// VARIABLES
// =====================================================

let students = [];
let fees = [];
let selectedTerm = 1;


// =====================================================
// LOAD DATA
// =====================================================

async function loadHallTicketData() {

    try {

        document.getElementById("loadingMessage").style.display = "block";

        const studentResult = await supabase
            .from("profiles")
            .select("id,full_name,mobile,class_name")
            .eq("role", "student");

        if (studentResult.error) {
            console.error(studentResult.error);
            alert("Failed to load students.");
            return;
        }

        const feeResult = await supabase
            .from("fees")
            .select("*");

        if (feeResult.error) {
            console.error(feeResult.error);
            alert("Failed to load fees.");
            return;
        }

        students = studentResult.data || [];
        fees = feeResult.data || [];

        displayHallTickets();

    } catch (error) {

        console.error(error);
        alert("Something went wrong.");

    } finally {

        document.getElementById("loadingMessage").style.display = "none";
    }
}


// =====================================================
// GET FEE
// =====================================================

function getFee(studentId) {

    for (let i = 0; i < fees.length; i++) {

        if (fees[i].student_id === studentId) {
            return fees[i];
        }
    }

    return null;
}


// =====================================================
// CALCULATE TERMS
// =====================================================

function calculateTerms(totalFee, paidFee) {

    totalFee = Number(totalFee) || 0;
    paidFee = Number(paidFee) || 0;

    const term1Total = Math.floor(totalFee / 3);
    const term2Total = Math.floor(totalFee / 3);
    const term3Total = totalFee - term1Total - term2Total;

    const term1Paid = Math.min(paidFee, term1Total);

    let remaining = paidFee - term1Paid;

    if (remaining < 0) {
        remaining = 0;
    }

    const term2Paid = Math.min(remaining, term2Total);

    remaining = remaining - term2Paid;

    if (remaining < 0) {
        remaining = 0;
    }

    const term3Paid = Math.min(remaining, term3Total);

    return {
        term1: {
            total: term1Total,
            paid: term1Paid,
            remaining: term1Total - term1Paid
        },
        term2: {
            total: term2Total,
            paid: term2Paid,
            remaining: term2Total - term2Paid
        },
        term3: {
            total: term3Total,
            paid: term3Paid,
            remaining: term3Total - term3Paid
        }
    };
}


// =====================================================
// GET TERM DATA
// =====================================================

function getTermData(student, termNumber) {

    const fee = getFee(student.id);

    if (!fee) {
        return null;
    }

    const totalFee = Number(
        fee.total_fee ||
        fee.total ||
        fee.amount ||
        0
    );

    const paidFee = Number(
        fee.paid_fee ||
        fee.paid ||
        fee.amount_paid ||
        0
    );

    const terms = calculateTerms(totalFee, paidFee);

    if (termNumber === 1) {
        return terms.term1;
    }

    if (termNumber === 2) {
        return terms.term2;
    }

    return terms.term3;
}


// =====================================================
// CHECK CLEARED
// =====================================================

function isTermCleared(student, termNumber) {

    const termData = getTermData(student, termNumber);

    if (!termData) {
        return false;
    }

    return termData.remaining <= 0;
}


// =====================================================
// STATISTICS
// =====================================================

function updateStatistics() {

    const total = students.length;

    let cleared = 0;

    for (let i = 0; i < students.length; i++) {

        if (isTermCleared(students[i], selectedTerm)) {
            cleared++;
        }
    }

    const pending = total - cleared;

    let clearedPercentage = 0;
    let pendingPercentage = 0;

    if (total > 0) {
        clearedPercentage = (cleared / total) * 100;
        pendingPercentage = (pending / total) * 100;
    }

    document.getElementById("totalStudents").textContent = total;

    document.getElementById("clearedStudents").textContent = cleared;

    document.getElementById("pendingStudents").textContent = pending;

    document.getElementById("clearedPercentage").textContent =
        clearedPercentage.toFixed(2) + "%";

    document.getElementById("pendingPercentage").textContent =
        pendingPercentage.toFixed(2) + "%";
}


// =====================================================
// GET CLEARED STUDENTS
// =====================================================

function getClearedStudents() {

    const result = [];

    for (let i = 0; i < students.length; i++) {

        if (isTermCleared(students[i], selectedTerm)) {
            result.push(students[i]);
        }
    }

    return result;
}


// =====================================================
// CLASS ORDER
// =====================================================

function getClassOrder(className) {

    if (!className) {
        return 999;
    }

    const value = String(className).toLowerCase().trim();

    if (value.includes("nursery")) {
        return 1;
    }

    if (value.includes("lkg")) {
        return 2;
    }

    if (value.includes("ukg")) {
        return 3;
    }

    const number = value.match(/[0-9]+/);

    if (number) {
        return 3 + Number(number[0]);
    }

    return 999;
}


// =====================================================
// SORT
// =====================================================

function sortStudents(data) {

    return data.sort(function(a, b) {

        const classA = getClassOrder(a.class_name);
        const classB = getClassOrder(b.class_name);

        if (classA !== classB) {
            return classA - classB;
        }

        const nameA = String(a.full_name || "");
        const nameB = String(b.full_name || "");

        return nameA.localeCompare(nameB);
    });
}


// =====================================================
// FILTERED CLEARED STUDENTS
// =====================================================

function getFilteredStudents() {

    let data = getClearedStudents();

    const search = String(
        document.getElementById("searchInput").value || ""
    ).toLowerCase().trim();

    const classSearch = String(
        document.getElementById("classInput").value || ""
    ).toLowerCase().trim();

    data = data.filter(function(student) {

        const name = String(student.full_name || "").toLowerCase();
        const mobile = String(student.mobile || "").toLowerCase();
        const className = String(student.class_name || "").toLowerCase();

        const searchMatch =
            search === "" ||
            name.includes(search) ||
            mobile.includes(search) ||
            className.includes(search);

        const classMatch =
            classSearch === "" ||
            className.includes(classSearch);

        return searchMatch && classMatch;
    });

    sortStudents(data);

    return data;
}


// =====================================================
// DISPLAY
// =====================================================

function displayHallTickets() {

    updateStatistics();

    const container = document.getElementById("studentsContainer");
    const emptyMessage = document.getElementById("emptyMessage");

    document.getElementById("selectedTermText").textContent =
        getTermName(selectedTerm);

    const data = getFilteredStudents();

    document.getElementById("eligibleCount").textContent = data.length;

    if (data.length === 0) {

        container.innerHTML = "";
        emptyMessage.style.display = "block";

        return;
    }

    emptyMessage.style.display = "none";

    let html = "";

    for (let i = 0; i < data.length; i++) {

        const student = data[i];

        html +=
            '<div class="student-card">' +
                '<div class="student-info">' +
                    '<div class="student-name">' +
                        escapeHTML(student.full_name || "Unknown Student") +
                    '</div>' +
                    '<div class="student-details">' +
                        'Class: ' +
                        escapeHTML(student.class_name || "Not Available") +
                    '</div>' +
                '</div>' +

                '<button class="download-button" ' +
                    'onclick="downloadHallTicket(\'' +
                    student.id +
                    '\')">' +
                    '📥 Download Hall Ticket' +
                '</button>' +
            '</div>';
    }

    container.innerHTML = html;
}


// =====================================================
// TERM SELECT
// =====================================================

window.selectTerm = function(termNumber) {

    selectedTerm = Number(termNumber);

    const buttons = document.querySelectorAll(".term-button");

    for (let i = 0; i < buttons.length; i++) {
        buttons[i].classList.remove("active");
    }

    const selectedButton =
        document.getElementById("termButton" + selectedTerm);

    if (selectedButton) {
        selectedButton.classList.add("active");
    }

    displayHallTickets();
};


// =====================================================
// SEARCH
// =====================================================

window.filterHallTickets = function() {
    displayHallTickets();
};


window.clearSearch = function() {

    document.getElementById("searchInput").value = "";
    document.getElementById("classInput").value = "";

    displayHallTickets();
};


// =====================================================
// TERM NAME
// =====================================================

function getTermName(termNumber) {

    if (termNumber === 1) {
        return "1st Term";
    }

    if (termNumber === 2) {
        return "2nd Term";
    }

    return "3rd Term";
}


// =====================================================
// EXAM NAME
// =====================================================

function getExamName(termNumber) {

    if (termNumber === 1) {
        return "FA - I";
    }

    if (termNumber === 2) {
        return "FA - II";
    }

    return "FA - III";
}


// =====================================================
// CREATE HALL TICKET
// =====================================================

function createHallTicket(student) {

    const name = escapeHTML(
        student.full_name || "________________"
    );

    const className = escapeHTML(
        student.class_name || "________________"
    );

    const exam = getExamName(selectedTerm);

    let html = "";

    html += '<div class="hall-ticket">';

    html +=
        '<div class="hall-header">' +

            '<img class="hall-logo" ' +
            'src="vision_school_logo.png" ' +
            'crossorigin="anonymous">' +

            '<div class="hall-school-name">' +
                'VISION THE SCHOOL OF EXCELLENCE' +
            '</div>' +

            '<div class="hall-tagline">' +
                '“A NEW ERA OF EDUCATION AWAITS”' +
            '</div>' +

            '<div class="hall-address">' +
                'Sri ram colony, Jalpally, balapur (M), RR (Dist), Pincode 500005.' +
            '</div>' +

            '<div class="hall-title">' +
                'HALLTICKET' +
            '</div>' +

        '</div>';

    html += '<div class="hall-body">';

    html +=
        '<div class="hall-row hall-row-name">' +
            '<div class="hall-label">Name of the Student :</div>' +
            '<div class="hall-line">' + name + '</div>' +
        '</div>';

    html +=
        '<div class="hall-row">' +
            '<div class="hall-label">Roll No / VSX ID :</div>' +
            '<div class="hall-line">&nbsp;</div>' +
        '</div>';

    html +=
        '<div class="hall-row">' +
            '<div class="hall-label">Class :</div>' +
            '<div class="hall-line">' + className + '</div>' +
        '</div>';

    html += '</div>';

    html +=
        '<div class="hall-exam">' +
            'Exam : ' + exam +
        '</div>';

    html +=
        '<div class="hall-signature">' +
            '<div class="hall-signature-line"></div>' +
            'Authorised Signature with Stamp' +
        '</div>';

    html += '</div>';

    return html;
}


// =====================================================
// CREATE CANVAS
// =====================================================

async function makeTicketCanvas(student) {

    const container =
        document.getElementById("pdfHallTicketContainer");

    container.innerHTML = createHallTicket(student);

    const ticket =
        container.querySelector(".hall-ticket");

    return await html2canvas(ticket, {
        scale: 3,
        useCORS: true,
        backgroundColor: "#ffffff"
    });
}


// =====================================================
// DOWNLOAD ONE
// =====================================================

window.downloadHallTicket = async function(studentId) {

    const student = students.find(function(item) {
        return item.id === studentId;
    });

    if (!student) {
        alert("Student not found.");
        return;
    }

    if (!isTermCleared(student, selectedTerm)) {
        alert("This student's fee is not cleared for this term.");
        return;
    }

    try {

        const canvas = await makeTicketCanvas(student);

        const image = canvas.toDataURL("image/png");

        const jsPDF = window.jspdf.jsPDF;

        const pdf = new jsPDF(
            "landscape",
            "mm",
            "a4"
        );

        const pageWidth = pdf.internal.pageSize.getWidth();
        const pageHeight = pdf.internal.pageSize.getHeight();

        const ticketWidth = 100;
        const ticketHeight = 85;

        const x = (pageWidth - ticketWidth) / 2;
        const y = (pageHeight - ticketHeight) / 2;

        pdf.addImage(
            image,
            "PNG",
            x,
            y,
            ticketWidth,
            ticketHeight
        );

        const studentName =
            String(student.full_name || "Student")
            .replace(/[^a-zA-Z0-9]/g, "_");

        pdf.save(
            studentName +
            "_" +
            getTermName(selectedTerm).replace(" ", "_") +
            "_Hall_Ticket.pdf"
        );

    } catch (error) {

        console.error(error);
        alert("Failed to create hall ticket.");

    } finally {

        document.getElementById("pdfHallTicketContainer").innerHTML = "";
    }
};


// =====================================================
// DOWNLOAD ALL - 6 HALL TICKETS PER A4
// =====================================================

window.downloadAllHallTickets = async function() {

    const data = getFilteredStudents();

    if (data.length === 0) {
        alert("No cleared students found.");
        return;
    }

    const confirmed = confirm(
        "Download " +
        data.length +
        " hall tickets for " +
        getTermName(selectedTerm) +
        "?"
    );

    if (!confirmed) {
        return;
    }

    try {

        const jsPDF = window.jspdf.jsPDF;

        const pdf = new jsPDF(
            "portrait",
            "mm",
            "a4"
        );

        const pageWidth = pdf.internal.pageSize.getWidth();
        const pageHeight = pdf.internal.pageSize.getHeight();

        /*
         * A4 = 210 x 297 mm
         *
         * 6 tickets:
         * 2 columns
         * 3 rows
         */

        const marginX = 5;
        const marginY = 5;

        const gapX = 3;
        const gapY = 3;

        const ticketWidth =
            (pageWidth - (marginX * 2) - gapX) / 2;

        const ticketHeight =
            (pageHeight - (marginY * 2) - (gapY * 2)) / 3;

        const container =
            document.getElementById("pdfHallTicketContainer");

        for (let i = 0; i < data.length; i++) {

            const student = data[i];

            container.innerHTML =
                createHallTicket(student);

            const ticket =
                container.querySelector(".hall-ticket");

            /*
             * Make the canvas from the actual ticket.
             * The PDF position scales it into the 2 x 3 grid.
             */

            const canvas = await html2canvas(ticket, {
                scale: 3,
                useCORS: true,
                backgroundColor: "#ffffff"
            });

            const image = canvas.toDataURL("image/png");

            const position = i % 6;

            const column = position % 2;
            const row = Math.floor(position / 2);

            const x =
                marginX +
                column * (ticketWidth + gapX);

            const y =
                marginY +
                row * (ticketHeight + gapY);

            if (position === 0 && i !== 0) {
                pdf.addPage();
            }

            /*
             * Add a small border around each ticket.
             */

            pdf.addImage(
                image,
                "PNG",
                x,
                y,
                ticketWidth,
                ticketHeight
            );

            pdf.setDrawColor(80, 80, 80);
            pdf.rect(
                x,
                y,
                ticketWidth,
                ticketHeight
            );
        }

        pdf.save(
            getTermName(selectedTerm).replace(" ", "_") +
            "_All_Hall_Tickets_6_Per_A4.pdf"
        );

    } catch (error) {

        console.error(error);
        alert("Failed to create hall tickets.");

    } finally {

        document.getElementById("pdfHallTicketContainer").innerHTML = "";
    }
};


// =====================================================
// BACK
// =====================================================

window.goBackToFees = function() {

    window.location.href = "collection_fees.html";
};


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHTML(value) {

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


// =====================================================
// START
// =====================================================

loadHallTicketData();
